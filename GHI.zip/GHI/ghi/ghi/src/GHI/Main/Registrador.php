<?php

namespace GHi\Main;

abstract class Registrador{

    private $horariodeinicio:time;
    
    function registrarnatabela(tabela):bol {
        return 1;
    }
}