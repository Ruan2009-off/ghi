<?php

namespace GHI\Login;

abstract class Organizacao{
    private $email;
    private $nome;
}