<?php

namespace GHI\Login;

class empresa extends Organizacao{

}