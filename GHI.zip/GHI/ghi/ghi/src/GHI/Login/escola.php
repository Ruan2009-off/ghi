<?php

namespace GHI\Login;

class escola extends Organizacao{
    
}