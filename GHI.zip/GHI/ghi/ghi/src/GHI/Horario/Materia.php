<?php

namespace GHI\Materia;

class Materia{

    private $nome:string;

    public function inserirnatabela(tabela):bool {
        return 1;
    }
}