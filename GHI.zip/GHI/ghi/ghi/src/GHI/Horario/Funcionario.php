<?php

namespace GHI\Horario;
use GHI\Main\Registrador;


class Funcionario extends Registrador{

    private $horariodechegada:time;
}