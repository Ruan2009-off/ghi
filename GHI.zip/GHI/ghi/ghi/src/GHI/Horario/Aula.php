<?php

namespace GHI\Horario;

class Aula{
    private $horariodefim:time;
    private $materia:Materia;

    public function Pesquisar(tabela):bool {

        return 1;
    }
}