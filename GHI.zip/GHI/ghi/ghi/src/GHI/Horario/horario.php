<?php

namespace GHI\Horario;

class horario{

    private $horariodeinicio:time;
    private $horariodefim:time;
}